package com.cg.moduletest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.moduletest.*;
import com.cg.moduletest.bean.WallPost;
import com.cg.moduletest.dao.IWallPostDao;
import com.cg.moduletest.*;

@Service
public class WallPostServiceImpl implements IWallPostService{
   
    @Autowired
    IWallPostDao WallPostDao;
    
    
    
    



	@Override
	public WallPost addWallPost(WallPost wallpost) {
		// TODO Auto-generated method stub
		return null;
	}

 


}