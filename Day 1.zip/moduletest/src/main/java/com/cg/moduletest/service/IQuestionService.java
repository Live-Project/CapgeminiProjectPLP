//package com.cg.moduletest.service;
//
//import com.cg.moduletest.bean.Question;
//
//public interface IQuestionService {
//
//	Question addQuestion(Question question);
//
//	
//
//	
//	
//}
