package com.cg.moduletest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.moduletest.bean.*;

public interface IWallPostDao extends JpaRepository<WallPost, Integer>{

}
