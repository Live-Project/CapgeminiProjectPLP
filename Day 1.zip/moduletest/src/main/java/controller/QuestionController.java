package controller;
//package com.cg.moduletest.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cg.moduletest.bean.Question;
//import com.cg.moduletest.service.IQuestionService;
//
//@CrossOrigin(origins="http://localhost:4200")
//@RestController
//
//public class QuestionController {
//	
//	
//	@Autowired
//	IQuestionService questionservice;
//
//
//	@RequestMapping(value="/user/add" ,method=RequestMethod.POST)
//	public Question addQuestion(@RequestBody Question question) 
//	{
//		
//		return questionservice.addQuestion(question);
//		 //return new ResponseEntity<String>("Your Account Id is "+bank.getAccountId()+"", HttpStatus.OK);
//	}
//	
//	
//}
