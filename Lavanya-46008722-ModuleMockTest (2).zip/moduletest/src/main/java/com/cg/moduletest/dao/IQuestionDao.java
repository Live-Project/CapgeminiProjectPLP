package com.cg.moduletest.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.moduletest.bean.Question;

public interface IQuestionDao extends JpaRepository<Question,Integer>{

}
