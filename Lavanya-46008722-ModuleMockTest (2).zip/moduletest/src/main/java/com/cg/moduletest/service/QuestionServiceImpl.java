package com.cg.moduletest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.moduletest.bean.Question;
import com.cg.moduletest.dao.IQuestionDao;

import com.cg.moduletest.service.IQuestionService;

@Service
public class QuestionServiceImpl implements IQuestionService
{
@Autowired
IQuestionDao QuestionDao;

@Override
public Question addQuestion(Question question)  {

		return QuestionDao.save(question);
	
}
}

