package com.cg.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.WallPost;
import com.cg.dao.IWallPostDao;

@Service
public class WallPostServiceImpl implements IWallPostService{
   
    @Autowired
    IWallPostDao WallPostDao;
    
    
    
    @Override
    public WallPost addWallPost(WallPost wallpost) {
        
        return WallPostDao.save(wallpost);
    }

 


}