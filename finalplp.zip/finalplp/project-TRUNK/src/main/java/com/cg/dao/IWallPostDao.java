package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.WallPost;

public interface IWallPostDao extends JpaRepository<WallPost, Integer>{

}
