package com.cg.project;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import controller.FileUploadController;

@SpringBootApplication

@ComponentScan({"com.cg.project","controller"})

public class ProjectApplication {

	public static void main(String[] args) {
		
		new File(FileUploadController.uploadDirectory).mkdir();
		
		SpringApplication.run(ProjectApplication.class, args);
	
		
	}

}
