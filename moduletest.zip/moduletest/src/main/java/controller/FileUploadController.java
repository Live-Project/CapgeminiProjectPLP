package controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RestController;
import com.cg.moduletest.bean.WallPost;
import com.cg.moduletest.service.IWallPostService;
import com.cg.moduletest.service.WallPostServiceImpl;


//@CrossOrigin(origins="http://localhost:4200")
//@RestController
@Controller
public class FileUploadController {
//	@Autowired
//	IWallPostService wallpostService;

	public static String uploadDirectory = System.getProperty("user.dir") + "/uploads";

	@RequestMapping("/")
	public String UploadPage(Model model) {
		return "uploadview";
	}

	@PostMapping("/upload")
	
	public String upload(Model model, @RequestParam("files") MultipartFile[] files)
{
	StringBuilder fileNames=new StringBuilder();
	
	for(MultipartFile file : files)
	{
		java.nio.file.Path fileNameAndPath = Paths.get(uploadDirectory,file.getOriginalFilename());
		
		fileNames.append(file.getOriginalFilename());
		
		try
		{
			Files.write(fileNameAndPath, file.getBytes());
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

model.addAttribute("msg","Successfully uploaded files" +fileNames.toString());
return "uploadStatusview";
//return wallpostService.addWallPost(model);

}
 
}
