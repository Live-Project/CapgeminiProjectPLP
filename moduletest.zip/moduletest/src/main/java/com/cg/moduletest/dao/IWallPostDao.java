package com.cg.moduletest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.moduletest.bean.*;
@Transactional
public interface IWallPostDao extends JpaRepository<WallPost, Integer>{

}
