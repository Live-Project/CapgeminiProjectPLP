package com.cg.moduletest;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import controller.FileUploadController;
@SpringBootApplication



@ComponentScan(basePackages = {"controller"})
public class ModuletestApplication {

	public static void main(String[] args) {
		new File(FileUploadController.uploadDirectory).mkdir();
		 SpringApplication.run(ModuletestApplication.class, args);
	}

}
