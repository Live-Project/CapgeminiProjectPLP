package com.cg.moduletest.service;

import com.cg.moduletest.bean.*;

public interface IWallPostService {

	

	WallPost addWallPost(WallPost wallpost);

	//WallPost addWallPost(IWallPostService wallpost);

}
