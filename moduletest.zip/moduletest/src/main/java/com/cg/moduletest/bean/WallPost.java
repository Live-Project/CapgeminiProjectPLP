package com.cg.moduletest.bean;

 

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

 

@Entity
@Table(name = "WallPost")
public class WallPost {

 

    @Id
    @GeneratedValue
    private int id;
    // @Pattern(regexp="[A-Z][a-z]*")
    @Column
    private String wallpost;
    
    @Column(name = "CREATED_DATE")
    Timestamp date;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWallpost() {
		return wallpost;
	}

	public void setWallpost(String wallpost) {
		this.wallpost = wallpost;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "WallPost [id=" + id + ", wallpost=" + wallpost + ", date=" + date + "]";
	}

	
}