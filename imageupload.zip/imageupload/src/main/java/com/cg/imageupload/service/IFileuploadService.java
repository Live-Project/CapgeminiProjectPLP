package com.cg.imageupload.service;

public interface IFileuploadService {

}
